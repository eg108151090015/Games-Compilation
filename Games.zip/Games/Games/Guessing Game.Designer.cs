﻿namespace Games
{
    partial class gg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.back1 = new System.Windows.Forms.Button();
            this.game1 = new System.Windows.Forms.Label();
            this.guess = new System.Windows.Forms.TextBox();
            this.check = new System.Windows.Forms.Button();
            this.score = new System.Windows.Forms.Label();
            this.play_again = new System.Windows.Forms.Button();
            this.correct_num = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // back1
            // 
            this.back1.BackColor = System.Drawing.Color.SteelBlue;
            this.back1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.back1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.back1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back1.Location = new System.Drawing.Point(215, 307);
            this.back1.Name = "back1";
            this.back1.Size = new System.Drawing.Size(96, 33);
            this.back1.TabIndex = 1;
            this.back1.Text = "Main menu";
            this.back1.UseVisualStyleBackColor = false;
            this.back1.Click += new System.EventHandler(this.back1_Click);
            // 
            // game1
            // 
            this.game1.AutoSize = true;
            this.game1.BackColor = System.Drawing.Color.Transparent;
            this.game1.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.game1.ForeColor = System.Drawing.Color.White;
            this.game1.Location = new System.Drawing.Point(96, 53);
            this.game1.Name = "game1";
            this.game1.Size = new System.Drawing.Size(324, 70);
            this.game1.TabIndex = 2;
            this.game1.Text = "Guess the number between\r\n1 and 100";
            this.game1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guess
            // 
            this.guess.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guess.Location = new System.Drawing.Point(147, 142);
            this.guess.Name = "guess";
            this.guess.Size = new System.Drawing.Size(221, 32);
            this.guess.TabIndex = 4;
            this.guess.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guess.TextChanged += new System.EventHandler(this.guess_TextChanged);
            // 
            // check
            // 
            this.check.BackColor = System.Drawing.Color.CornflowerBlue;
            this.check.Cursor = System.Windows.Forms.Cursors.Hand;
            this.check.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.check.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.check.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.check.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check.ForeColor = System.Drawing.Color.Black;
            this.check.Location = new System.Drawing.Point(215, 268);
            this.check.Name = "check";
            this.check.Size = new System.Drawing.Size(95, 33);
            this.check.TabIndex = 5;
            this.check.Text = "Check";
            this.check.UseVisualStyleBackColor = false;
            this.check.Click += new System.EventHandler(this.check_Click);
            // 
            // score
            // 
            this.score.AutoSize = true;
            this.score.BackColor = System.Drawing.Color.Transparent;
            this.score.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.score.ForeColor = System.Drawing.Color.White;
            this.score.Location = new System.Drawing.Point(201, 187);
            this.score.Name = "score";
            this.score.Size = new System.Drawing.Size(112, 27);
            this.score.TabIndex = 6;
            this.score.Text = "Guesses: 0";
            // 
            // play_again
            // 
            this.play_again.BackColor = System.Drawing.Color.CornflowerBlue;
            this.play_again.Cursor = System.Windows.Forms.Cursors.Hand;
            this.play_again.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.play_again.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.play_again.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.play_again.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.play_again.ForeColor = System.Drawing.Color.Black;
            this.play_again.Location = new System.Drawing.Point(215, 268);
            this.play_again.Name = "play_again";
            this.play_again.Size = new System.Drawing.Size(98, 33);
            this.play_again.TabIndex = 7;
            this.play_again.Text = "Play Again";
            this.play_again.UseVisualStyleBackColor = false;
            this.play_again.Click += new System.EventHandler(this.play_again_Click);
            // 
            // correct_num
            // 
            this.correct_num.AutoSize = true;
            this.correct_num.BackColor = System.Drawing.Color.Transparent;
            this.correct_num.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.correct_num.ForeColor = System.Drawing.Color.White;
            this.correct_num.Location = new System.Drawing.Point(160, 226);
            this.correct_num.Name = "correct_num";
            this.correct_num.Size = new System.Drawing.Size(164, 27);
            this.correct_num.TabIndex = 8;
            this.correct_num.Text = "Correct number:";
            // 
            // gg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.BackgroundImage = global::Games.Properties.Resources.gg2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(511, 343);
            this.Controls.Add(this.correct_num);
            this.Controls.Add(this.play_again);
            this.Controls.Add(this.score);
            this.Controls.Add(this.check);
            this.Controls.Add(this.guess);
            this.Controls.Add(this.game1);
            this.Controls.Add(this.back1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "gg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Guessing Game";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button back1;
        private System.Windows.Forms.Label game1;
        private System.Windows.Forms.TextBox guess;
        private System.Windows.Forms.Button check;
        private System.Windows.Forms.Label score;
        private System.Windows.Forms.Button play_again;
        private System.Windows.Forms.Label correct_num;
    }
}