﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Games
{
    public partial class gg : Form
    {

        public gg()
        {
            InitializeComponent();
            load_question();
            play_again.Hide();
            correct_num.Hide();
        }

        Random random = new Random();
        int guesses = 0;
        int correct = 0;
        Int32 i;

        private void load_question()
        {
            correct = random.Next(1, 101);
        }

        private void exit_btn3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to exit?", "Exit message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void back1_Click(object sender, EventArgs e)
        {
            this.Hide();
            main_menu form2 = new main_menu();
            form2.Show();
        }

        private void guess_TextChanged(object sender, EventArgs e)
        {
            guess.Focus();
        }

        private void check_Click(object sender, EventArgs e)
        {

            if (guess.Text == "" || guess is null)
            {
                MessageBox.Show("Please enter a number");
                guess.Clear();
            }

            else
            {
                i = Int32.Parse(guess.Text);
                guesses++;
                score.Text = score.Text = "Guesses: " + guesses;

                if (i < 1 || i > 100)
                {
                    MessageBox.Show("Enter a number between 1 and 100");
                    guess.Clear();
                }

                else if (i == correct)
                {
                    score.Text = "Guesses: " + guesses;
                    correct_num.Text = "Correct number: " + correct;
                    MessageBox.Show("You got it!");
                    guess.Clear();
                    check.Hide();
                    correct_num.Show();
                    play_again.Show();
                }
                else if (i < correct)
                {
                    score.Text = "Guesses: " + guesses;
                    MessageBox.Show("Too low, try again");
                    guess.Clear();
                }
                else if (i > correct)
                {
                    score.Text = "Guesses: " + guesses;
                    MessageBox.Show("Too high, try again");
                    guess.Clear();
                }
            }
        }

        private void play_again_Click(object sender, EventArgs e)
        {
            this.Hide();
            gg form3 = new gg();
            form3.Show();           
        }
    }
}