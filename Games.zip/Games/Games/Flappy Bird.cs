﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Games
{
    public partial class fb : Form
    {
        bool GameOver = false;
        public fb()
        {
            InitializeComponent();
            game_over.Hide();
            timer1.Stop();
            scoreText.Hide();
            q_r.Hide();
        }

        int gravity = 18;
        int speed = 5;
        int score = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {
            bird.Top += gravity;
            pipe_down1.Left -= speed;
            pipe_up1.Left -= speed;
            pipe_down2.Left -= speed;
            pipe_up2.Left -= speed;
            pipe_down3.Left -= speed;
            pipe_up3.Left -= speed;
            scoreText.Text = "Score: " + score;

            if (pipe_down1.Left < -115)
            {
                pipe_down1.Left = 800;
                score++;
            }

            if (pipe_up1.Left < -115)
            {
                pipe_up1.Left = 800;
            }

            if (pipe_down2.Left < -115)
            {
                pipe_down2.Left = 800;
                score++;
            }

            if (pipe_up2.Left < -115)
            {
                pipe_up2.Left = 800;
            }

            if (pipe_down3.Left < -115)
            {
                pipe_down3.Left = 800;
                score++;
            }

            if (pipe_up3.Left < -115)
            {
                pipe_up3.Left = 800;
            }

            if (bird.Bounds.IntersectsWith(pipe_down1.Bounds) || 
                bird.Bounds.IntersectsWith(pipe_up1.Bounds) ||
                bird.Bounds.IntersectsWith(pipe_down2.Bounds) ||
                bird.Bounds.IntersectsWith(pipe_up2.Bounds) ||
                bird.Bounds.IntersectsWith(pipe_down3.Bounds) ||
                bird.Bounds.IntersectsWith(pipe_up3.Bounds) ||
                bird.Bounds.IntersectsWith(grass.Bounds) || 
                bird.Top < 10)
            {
                end_game();
            }

            if (score > 5 && score % 5 == 0)
            {
                speed = speed + 1;
            }

        }

        private void end_game()
        {
            timer1.Stop();
            game_over.Show();
            q_r.Show();
            GameOver = true;
        }

        private void fb_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = 18;
            }
        }

        private void fb_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = -18;
            }
        }

        private void fb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (GameOver)
            {
                if (e.KeyChar == 'R' || e.KeyChar == 'r')
                {
                    GameOver = false;
                    this.Hide();
                    fb form6 = new fb();
                    form6.Show();
                }

                if (e.KeyChar == 'Q' || e.KeyChar == 'q')
                {
                    GameOver = false;
                    this.Hide();                  
                    main_menu form2 = new main_menu();
                    form2.Show();                    
                }
            }
            else
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    press_enter.Hide();
                    scoreText.Show();
                    timer1.Start();
                }
            }
        }

        private void exit_btn6_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to exit?", "Exit message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void back4_Click(object sender, EventArgs e)
        {
            this.Hide();
            main_menu form2 = new main_menu();
            form2.Show();           
        }

        private void play_again_Click(object sender, EventArgs e)
        {
            this.Hide();
            fb form6 = new fb();
            form6.Show();
        }
    }
}