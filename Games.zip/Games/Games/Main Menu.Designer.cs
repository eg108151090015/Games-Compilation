﻿namespace Games
{
    partial class main_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.main = new System.Windows.Forms.Label();
            this.logout = new System.Windows.Forms.Button();
            this.credits = new System.Windows.Forms.Button();
            this.loading = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.guessing_game = new System.Windows.Forms.PictureBox();
            this.ttt = new System.Windows.Forms.PictureBox();
            this.flappy_bird = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.exit_btn2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guessing_game)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ttt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flappy_bird)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // main
            // 
            this.main.AutoSize = true;
            this.main.BackColor = System.Drawing.Color.Transparent;
            this.main.Font = new System.Drawing.Font("Showcard Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.main.ForeColor = System.Drawing.Color.White;
            this.main.Location = new System.Drawing.Point(82, 26);
            this.main.Name = "main";
            this.main.Size = new System.Drawing.Size(387, 66);
            this.main.TabIndex = 1;
            this.main.Text = "Compilation of C# Games\r\nin ITEC21";
            this.main.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // logout
            // 
            this.logout.BackColor = System.Drawing.Color.SteelBlue;
            this.logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.logout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout.ForeColor = System.Drawing.Color.Black;
            this.logout.Location = new System.Drawing.Point(6, 6);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(102, 32);
            this.logout.TabIndex = 4;
            this.logout.Text = "Logout";
            this.logout.UseVisualStyleBackColor = false;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // credits
            // 
            this.credits.BackColor = System.Drawing.Color.PowderBlue;
            this.credits.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.credits.Cursor = System.Windows.Forms.Cursors.Hand;
            this.credits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.credits.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.credits.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CadetBlue;
            this.credits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.credits.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.credits.ForeColor = System.Drawing.Color.Black;
            this.credits.Location = new System.Drawing.Point(117, 6);
            this.credits.Name = "credits";
            this.credits.Size = new System.Drawing.Size(319, 32);
            this.credits.TabIndex = 9;
            this.credits.Text = "Credits";
            this.credits.UseVisualStyleBackColor = false;
            this.credits.Click += new System.EventHandler(this.credits_Click);
            // 
            // loading
            // 
            this.loading.AutoSize = true;
            this.loading.BackColor = System.Drawing.Color.DimGray;
            this.loading.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loading.ForeColor = System.Drawing.Color.White;
            this.loading.Location = new System.Drawing.Point(12, 318);
            this.loading.Name = "loading";
            this.loading.Size = new System.Drawing.Size(33, 33);
            this.loading.TabIndex = 12;
            this.loading.Text = "...";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 354);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(527, 15);
            this.progressBar1.TabIndex = 14;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.guessing_game, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.ttt, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.flappy_bird, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel1.ForeColor = System.Drawing.Color.White;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(-2, 115);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(555, 192);
            this.tableLayoutPanel1.TabIndex = 18;
            // 
            // guessing_game
            // 
            this.guessing_game.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guessing_game.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guessing_game.Image = global::Games.Properties.Resources.gg1;
            this.guessing_game.Location = new System.Drawing.Point(373, 6);
            this.guessing_game.Name = "guessing_game";
            this.guessing_game.Size = new System.Drawing.Size(176, 149);
            this.guessing_game.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guessing_game.TabIndex = 23;
            this.guessing_game.TabStop = false;
            this.guessing_game.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // ttt
            // 
            this.ttt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ttt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ttt.Image = global::Games.Properties.Resources.ttt;
            this.ttt.Location = new System.Drawing.Point(189, 6);
            this.ttt.Name = "ttt";
            this.ttt.Size = new System.Drawing.Size(175, 149);
            this.ttt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ttt.TabIndex = 22;
            this.ttt.TabStop = false;
            this.ttt.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // flappy_bird
            // 
            this.flappy_bird.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flappy_bird.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flappy_bird.Image = global::Games.Properties.Resources.f2;
            this.flappy_bird.Location = new System.Drawing.Point(6, 6);
            this.flappy_bird.Name = "flappy_bird";
            this.flappy_bird.Size = new System.Drawing.Size(174, 149);
            this.flappy_bird.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.flappy_bird.TabIndex = 20;
            this.flappy_bird.TabStop = false;
            this.flappy_bird.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkCyan;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(373, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(176, 28);
            this.label3.TabIndex = 21;
            this.label3.Text = "Guessing Game";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkCyan;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(189, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(175, 28);
            this.label2.TabIndex = 20;
            this.label2.Text = "Tic Tac Toe";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkCyan;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 161);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 28);
            this.label1.TabIndex = 19;
            this.label1.Text = "Flappy Bird";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.Controls.Add(this.exit_btn2, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.logout, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.credits, 1, 0);
            this.tableLayoutPanel2.ForeColor = System.Drawing.Color.White;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(-2, 339);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(555, 44);
            this.tableLayoutPanel2.TabIndex = 19;
            // 
            // exit_btn2
            // 
            this.exit_btn2.BackColor = System.Drawing.Color.Firebrick;
            this.exit_btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exit_btn2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.exit_btn2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.exit_btn2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.exit_btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit_btn2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_btn2.ForeColor = System.Drawing.Color.Black;
            this.exit_btn2.Location = new System.Drawing.Point(445, 6);
            this.exit_btn2.Name = "exit_btn2";
            this.exit_btn2.Size = new System.Drawing.Size(104, 32);
            this.exit_btn2.TabIndex = 10;
            this.exit_btn2.Text = "Exit";
            this.exit_btn2.UseVisualStyleBackColor = false;
            this.exit_btn2.Click += new System.EventHandler(this.exit_btn2_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Games.Properties.Resources.bg211;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(552, 381);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // main_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::Games.Properties.Resources.bg231;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(552, 381);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.loading);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.main);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.tableLayoutPanel2);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "main_menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Menu";
            this.Load += new System.EventHandler(this.main_menu_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guessing_game)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ttt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flappy_bird)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label main;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Button credits;
        private System.Windows.Forms.Label loading;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button exit_btn2;
        private System.Windows.Forms.PictureBox flappy_bird;
        private System.Windows.Forms.PictureBox ttt;
        private System.Windows.Forms.PictureBox guessing_game;
    }
}