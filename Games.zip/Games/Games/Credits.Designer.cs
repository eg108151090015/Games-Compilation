﻿namespace Games
{
    partial class credits
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.name = new System.Windows.Forms.Label();
            this.eman = new System.Windows.Forms.PictureBox();
            this.back5 = new System.Windows.Forms.Button();
            this.crdts = new System.Windows.Forms.Label();
            this.vin = new System.Windows.Forms.PictureBox();
            this.name2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.eman)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vin)).BeginInit();
            this.SuspendLayout();
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.BackColor = System.Drawing.Color.Transparent;
            this.name.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.ForeColor = System.Drawing.Color.White;
            this.name.Location = new System.Drawing.Point(124, 99);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(324, 120);
            this.name.TabIndex = 0;
            this.name.Tag = "eman_info";
            this.name.Text = "Name: Gonzales, Emanuel M.\r\nAge: 19\r\nFrom: Sambong Tagaytay City\r\nCourse: BSIT";
            this.name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // eman
            // 
            this.eman.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.eman.Cursor = System.Windows.Forms.Cursors.Hand;
            this.eman.Image = global::Games.Properties.Resources.eman;
            this.eman.Location = new System.Drawing.Point(111, 248);
            this.eman.Name = "eman";
            this.eman.Size = new System.Drawing.Size(142, 126);
            this.eman.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.eman.TabIndex = 1;
            this.eman.TabStop = false;
            this.eman.Tag = "eman_info";
            this.eman.Click += new System.EventHandler(this.eman_Click);
            // 
            // back5
            // 
            this.back5.BackColor = System.Drawing.Color.SteelBlue;
            this.back5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.back5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.back5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back5.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back5.ForeColor = System.Drawing.Color.Black;
            this.back5.Location = new System.Drawing.Point(367, 336);
            this.back5.Name = "back5";
            this.back5.Size = new System.Drawing.Size(96, 33);
            this.back5.TabIndex = 30;
            this.back5.Text = "Main menu";
            this.back5.UseVisualStyleBackColor = false;
            this.back5.Click += new System.EventHandler(this.back4_Click);
            // 
            // crdts
            // 
            this.crdts.AutoSize = true;
            this.crdts.BackColor = System.Drawing.Color.Transparent;
            this.crdts.Font = new System.Drawing.Font("Comic Sans MS", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crdts.ForeColor = System.Drawing.Color.White;
            this.crdts.Location = new System.Drawing.Point(31, 31);
            this.crdts.Name = "crdts";
            this.crdts.Size = new System.Drawing.Size(496, 40);
            this.crdts.TabIndex = 32;
            this.crdts.Text = "Credits to the following creators:";
            // 
            // vin
            // 
            this.vin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.vin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.vin.Image = global::Games.Properties.Resources.vin;
            this.vin.Location = new System.Drawing.Point(111, 248);
            this.vin.Name = "vin";
            this.vin.Size = new System.Drawing.Size(142, 126);
            this.vin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.vin.TabIndex = 35;
            this.vin.TabStop = false;
            this.vin.Tag = "vin_info";
            this.vin.Click += new System.EventHandler(this.vin_Click);
            // 
            // name2
            // 
            this.name2.AutoSize = true;
            this.name2.BackColor = System.Drawing.Color.Transparent;
            this.name2.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name2.ForeColor = System.Drawing.Color.White;
            this.name2.Location = new System.Drawing.Point(138, 99);
            this.name2.Name = "name2";
            this.name2.Size = new System.Drawing.Size(298, 120);
            this.name2.TabIndex = 37;
            this.name2.Tag = "vin_info";
            this.name2.Text = "Name: Gonzales, Marvin M.\r\nAge: 22\r\nFrom: Batas, Silang, Cavite\r\nCourse: BSIT";
            this.name2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(52, 286);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(257, 54);
            this.label1.TabIndex = 40;
            this.label1.Text = "Click the \"Next\" button to\r\nsee the creators.";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(380, 270);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(68, 40);
            this.button1.TabIndex = 38;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGreen;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(380, 270);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(68, 40);
            this.button2.TabIndex = 39;
            this.button2.Text = "Next";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(180, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(219, 54);
            this.label2.TabIndex = 42;
            this.label2.Text = "Click the \"Picture\" to\r\nsee the creators info.";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // credits
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.BackgroundImage = global::Games.Properties.Resources.bg25;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(552, 381);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.name);
            this.Controls.Add(this.eman);
            this.Controls.Add(this.name2);
            this.Controls.Add(this.vin);
            this.Controls.Add(this.crdts);
            this.Controls.Add(this.back5);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "credits";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Credits";
            this.Load += new System.EventHandler(this.credits_Load);
            ((System.ComponentModel.ISupportInitialize)(this.eman)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label name;
        private System.Windows.Forms.PictureBox eman;
        private System.Windows.Forms.Button back5;
        private System.Windows.Forms.Label crdts;
        private System.Windows.Forms.PictureBox vin;
        private System.Windows.Forms.Label name2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
    }
}