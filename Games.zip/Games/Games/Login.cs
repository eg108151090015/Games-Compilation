﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Games
{
    public partial class login : Form
    {

        public login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pass_Click(object sender, EventArgs e)
        {

        }

        private void user_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void user_pass_TextChanged(object sender, EventArgs e)
        {

        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Do you want to exit?", "Exit message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)== DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void login_btn_Click(object sender, EventArgs e)
        {

            if ((user_name.Text == "ITEC21") && (user_pass.Text == "12345"))
            {
                this.Hide();
                MessageBox.Show("Welcome to ITEC21!");
                main_menu form2 = new main_menu();
                form2.Show();
            }

            else if ((user_name.Text == "ITEC21") && (user_pass.Text == ""))
            {
                MessageBox.Show("Please input your password!");
            }

            else if ((user_name.Text == "") && (user_pass.Text == "12345"))
            {
                MessageBox.Show("Please input your username!");
            }

            else if ((user_name.Text != "ITEC21") && (user_pass.Text == "12345"))
            {
                MessageBox.Show("Invalid user name!");
                user_name.Clear();
            }

            else if ((user_name.Text == "ITEC21") && (user_pass.Text != "12345"))
            {
                MessageBox.Show("Invalid password!");
                user_pass.Clear();
            }
            
            else if ((user_name.Text == "") && (user_pass.Text == ""))
            {
                MessageBox.Show("Please fill up your information!");
            }

            else if ((user_name.Text != "ITEC21") && (user_pass.Text != "12345"))
            {
                MessageBox.Show("Invalid credencial!");
                user_pass.Clear();
                user_name.Clear();
            }

        }

        private void show_pass_CheckedChanged(object sender, EventArgs e)
        {
            if (user_pass.PasswordChar == '*')
            {
                user_pass.PasswordChar = '\0';
            }
            else if (user_pass.PasswordChar == '\0')
            {
                user_pass.PasswordChar = '*';
            }
        }
    }
}
