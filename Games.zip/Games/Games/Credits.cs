﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Games
{
    public partial class credits : Form
    {

        public credits()
        {
            InitializeComponent();
        }

        private void back4_Click(object sender, EventArgs e)
        {
            this.Hide();
            main_menu form2 = new main_menu();
            form2.Show();
        }

        private void exit_btn6_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to exit?", "Exit message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void eman_Click(object sender, EventArgs e)
        {
            name.Show();
            label2.Hide();
        }

        private void credits_Load(object sender, EventArgs e)
        {
            name2.Visible = false;
            vin.Visible = false;
            eman.Visible = false;
            name.Visible = false;
            button1.Visible = false;
            label2.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Show();
            button2.Visible = true;
            button1.Visible = false;
            label1.Visible = false;
            vin.Visible = true;
            eman.Visible = false;
            name.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label2.Show();
            button2.Visible = false;
            button1.Visible = true;
            label1.Visible = false;
            name2.Visible = false;
            vin.Visible = false;
            eman.Visible = true;
        }

        private void vin_Click(object sender, EventArgs e)
        {
            label2.Hide();
            name2.Show();
        }
    }
}