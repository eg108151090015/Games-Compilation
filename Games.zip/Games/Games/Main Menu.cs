﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Games
{
    public partial class main_menu : Form
    {
        public main_menu()
        {
            InitializeComponent();
        }

        private void exit_btn2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to exit?", "Exit message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void guessing_game_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Welcome to Guessing Game!");
            gg form3 = new gg();
            form3.Show();           
        }

        private void logout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to logout?", "Logout message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                login form1 = new login();
                form1.Show();               
            }
        }

        private void brick_breaker_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Welcome to Tic Tac Toe!");
            tic_tac_toe form5 = new tic_tac_toe();
            form5.Show();           
        }

        private void flappy_bird_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Welcome to Flappy Bird!");
            fb form4 = new fb();
            form4.Show();           
        }

        private void credits_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Credits to the Creators!");
            credits form6 = new credits();
            form6.Show();            
        }

        private void main_menu_Load(object sender, EventArgs e)
        {
            main.Visible = false;
            guessing_game.Visible = false;
            flappy_bird.Visible = false;
            ttt.Visible = false;
            credits.Visible = false;
            logout.Visible = false;
            exit_btn2.Visible = false;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            loading.Text = "Now loading:"+progressBar1.Value;
            this.progressBar1.Increment(2);
            if(progressBar1.Value == 100)
            {
                main.Visible = true;
                guessing_game.Visible = true;
                flappy_bird.Visible = true;
                ttt.Visible = true;
                credits.Visible = true;
                logout.Visible = true;
                loading.Visible = false;
                progressBar1.Visible = false;
                pictureBox1.Visible = false;
                exit_btn2.Visible = true;
                timer1.Stop();
            }
        }

        private void exit_btn2_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to exit?", "Exit message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Welcome to Flappy Bird!");
            fb form4 = new fb();
            form4.Show();           
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Welcome to Tic Tac Toe!");
            tic_tac_toe form5 = new tic_tac_toe();
            form5.Show();            
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Welcome to Guessing Game!");
            gg form3 = new gg();
            form3.Show();            
        }
    }
}
