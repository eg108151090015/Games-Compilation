﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Games
{
    public partial class tic_tac_toe : Form
    {
        char who = 'O';
        short movement = 0;
        int X = 0;
        int O = 0;
        bool Computer = true;
        public tic_tac_toe()
        {
            InitializeComponent();
            modes.Enabled = true;
        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            who = 'O';
            movement = 0;
            button1.Enabled = true; button1.Text = ""; button1.BackColor = Color.SteelBlue;
            button2.Enabled = true; button2.Text = ""; button2.BackColor = Color.SteelBlue;
            button3.Enabled = true; button3.Text = ""; button3.BackColor = Color.SteelBlue;
            button4.Enabled = true; button4.Text = ""; button4.BackColor = Color.SteelBlue;
            button5.Enabled = true; button5.Text = ""; button5.BackColor = Color.SteelBlue;
            button6.Enabled = true; button6.Text = ""; button6.BackColor = Color.SteelBlue;
            button7.Enabled = true; button7.Text = ""; button7.BackColor = Color.SteelBlue;
            button8.Enabled = true; button8.Text = ""; button8.BackColor = Color.SteelBlue;
            button9.Enabled = true; button9.Text = ""; button9.BackColor = Color.SteelBlue;
            tableLayoutPanel1.Enabled = true;
        }

        private void infoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Scores:\n X Score:"+X+"\n O Score:"+O);
        }

        private void button(object sender, EventArgs e)
        {
            modes.Enabled = false;
            if (tableLayoutPanel1.Enabled == false)
            {
                return;
            }

            Button bt = sender as Button;

            if (bt.Enabled)
            {
                bt.Enabled = false;
                bt.BackColor = Color.DodgerBlue;

                if (who == 'O')
                {
                    bt.Text = "O";

                    if ((button1.Text == button2.Text && button2.Text == button3.Text && button2.Text != "") ||
                       (button4.Text == button5.Text && button5.Text == button6.Text && button5.Text != "") ||
                       (button7.Text == button8.Text && button8.Text == button9.Text && button8.Text != "") ||
                       (button1.Text == button4.Text && button4.Text == button7.Text && button4.Text != "") ||
                       (button2.Text == button5.Text && button5.Text == button8.Text && button5.Text != "") ||
                       (button3.Text == button6.Text && button6.Text == button9.Text && button6.Text != "") ||
                       (button1.Text == button5.Text && button5.Text == button9.Text && button5.Text != "") ||
                       (button3.Text == button5.Text && button5.Text == button7.Text && button5.Text != ""))
                    {
                        MessageBox.Show("The winner is " + who + "!");
                        modes.Enabled = true;
                        tableLayoutPanel1.Enabled = false;

                        if (who == 'X')
                        {
                            X++;
                        }

                        else
                        {
                            O++;
                        }

                    }

                    else if (movement == 8)
                    {
                        MessageBox.Show("Draw!");
                        modes.Enabled = true;
                        tableLayoutPanel1.Enabled = false;
                    }

                    who = 'X';

                }

                else if (who == 'X')
                {
                    bt.Text = "X";

                    if ((button1.Text == button2.Text && button2.Text == button3.Text && button2.Text != "") ||
                       (button4.Text == button5.Text && button5.Text == button6.Text && button5.Text != "") ||
                       (button7.Text == button8.Text && button8.Text == button9.Text && button8.Text != "") ||
                       (button1.Text == button4.Text && button4.Text == button7.Text && button4.Text != "") ||
                       (button2.Text == button5.Text && button5.Text == button8.Text && button5.Text != "") ||
                       (button3.Text == button6.Text && button6.Text == button9.Text && button6.Text != "") ||
                       (button1.Text == button5.Text && button5.Text == button9.Text && button5.Text != "") ||
                       (button3.Text == button5.Text && button5.Text == button7.Text && button5.Text != ""))
                    {
                        MessageBox.Show("The winner is " + who + "!");
                        modes.Enabled = true;
                        tableLayoutPanel1.Enabled = false;

                        if (who == 'X')
                        {
                            X++;
                        }

                        else
                        {
                            O++;
                        }

                    }

                    else if (movement == 8)
                    {
                        MessageBox.Show("Draw!");
                        modes.Enabled = true;
                        tableLayoutPanel1.Enabled = false;
                    }

                    who = 'O';

                }

                movement++;

                if (Computer && tableLayoutPanel1.Enabled && who == 'X')
                {
                    MakeComputerMove();
                }
            }
        }

        private void MakeComputerMove()
        {
            Random random = new Random();
            List<Button> availableButtons = new List<Button>();

            foreach (Control control in tableLayoutPanel1.Controls)
            {
                if (control is Button button && button.Enabled)
                {
                    availableButtons.Add(button);
                }
            }

            if (availableButtons.Count > 0)
            {
                int randomIndex = random.Next(availableButtons.Count);
                Button randomButton = availableButtons[randomIndex];

                randomButton.PerformClick();
            }
        }

        private void mainMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            main_menu form2 = new main_menu();
            form2.Show();
        }

        private void playerVsComputerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Computer = true;
            X = 0;
            O = 0;
            modes_text.Text = "Player vs. Computer";
        }

        private void playerVsPlayerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Computer = false;
            X = 0;
            O = 0;
            modes_text.Text = "Player vs. Player";
        }
    }
}
