﻿namespace Games
{
    partial class fb
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.scoreText = new System.Windows.Forms.Label();
            this.press_enter = new System.Windows.Forms.Label();
            this.game_over = new System.Windows.Forms.Label();
            this.bird = new System.Windows.Forms.PictureBox();
            this.pipe_up1 = new System.Windows.Forms.PictureBox();
            this.pipe_down1 = new System.Windows.Forms.PictureBox();
            this.grass = new System.Windows.Forms.PictureBox();
            this.q_r = new System.Windows.Forms.Label();
            this.pipe_up2 = new System.Windows.Forms.PictureBox();
            this.pipe_down2 = new System.Windows.Forms.PictureBox();
            this.pipe_up3 = new System.Windows.Forms.PictureBox();
            this.pipe_down3 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.bird)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_up1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_down1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_up2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_down2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_up3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_down3)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // scoreText
            // 
            this.scoreText.AutoSize = true;
            this.scoreText.BackColor = System.Drawing.Color.Transparent;
            this.scoreText.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreText.Location = new System.Drawing.Point(12, 9);
            this.scoreText.Name = "scoreText";
            this.scoreText.Size = new System.Drawing.Size(77, 22);
            this.scoreText.TabIndex = 2;
            this.scoreText.Text = "Score: 0";
            // 
            // press_enter
            // 
            this.press_enter.AutoSize = true;
            this.press_enter.BackColor = System.Drawing.Color.Transparent;
            this.press_enter.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.press_enter.ForeColor = System.Drawing.Color.Black;
            this.press_enter.Location = new System.Drawing.Point(175, 213);
            this.press_enter.Name = "press_enter";
            this.press_enter.Size = new System.Drawing.Size(482, 55);
            this.press_enter.TabIndex = 27;
            this.press_enter.Text = "Press \"Enter\" to Start";
            // 
            // game_over
            // 
            this.game_over.AutoSize = true;
            this.game_over.BackColor = System.Drawing.Color.Transparent;
            this.game_over.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.game_over.ForeColor = System.Drawing.Color.Black;
            this.game_over.Location = new System.Drawing.Point(262, 139);
            this.game_over.Name = "game_over";
            this.game_over.Size = new System.Drawing.Size(278, 55);
            this.game_over.TabIndex = 28;
            this.game_over.Text = "Game Over!";
            // 
            // bird
            // 
            this.bird.BackColor = System.Drawing.Color.Transparent;
            this.bird.Image = global::Games.Properties.Resources.bird2;
            this.bird.Location = new System.Drawing.Point(32, 170);
            this.bird.Name = "bird";
            this.bird.Size = new System.Drawing.Size(48, 40);
            this.bird.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bird.TabIndex = 1;
            this.bird.TabStop = false;
            // 
            // pipe_up1
            // 
            this.pipe_up1.BackColor = System.Drawing.Color.Transparent;
            this.pipe_up1.Image = global::Games.Properties.Resources.pipeu;
            this.pipe_up1.Location = new System.Drawing.Point(230, -164);
            this.pipe_up1.Name = "pipe_up1";
            this.pipe_up1.Size = new System.Drawing.Size(97, 300);
            this.pipe_up1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pipe_up1.TabIndex = 3;
            this.pipe_up1.TabStop = false;
            // 
            // pipe_down1
            // 
            this.pipe_down1.BackColor = System.Drawing.Color.Transparent;
            this.pipe_down1.Image = global::Games.Properties.Resources.piped;
            this.pipe_down1.Location = new System.Drawing.Point(230, 303);
            this.pipe_down1.Name = "pipe_down1";
            this.pipe_down1.Size = new System.Drawing.Size(97, 300);
            this.pipe_down1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pipe_down1.TabIndex = 4;
            this.pipe_down1.TabStop = false;
            // 
            // grass
            // 
            this.grass.Image = global::Games.Properties.Resources.ground;
            this.grass.Location = new System.Drawing.Point(-1, 416);
            this.grass.Name = "grass";
            this.grass.Size = new System.Drawing.Size(802, 65);
            this.grass.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.grass.TabIndex = 0;
            this.grass.TabStop = false;
            // 
            // q_r
            // 
            this.q_r.AutoSize = true;
            this.q_r.BackColor = System.Drawing.Color.Transparent;
            this.q_r.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q_r.ForeColor = System.Drawing.Color.Black;
            this.q_r.Location = new System.Drawing.Point(187, 213);
            this.q_r.Name = "q_r";
            this.q_r.Size = new System.Drawing.Size(449, 110);
            this.q_r.TabIndex = 32;
            this.q_r.Text = "Press \"R\" to Restart\r\nPress \"Q\" to Quit";
            this.q_r.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pipe_up2
            // 
            this.pipe_up2.BackColor = System.Drawing.Color.Transparent;
            this.pipe_up2.Image = global::Games.Properties.Resources.pipeu;
            this.pipe_up2.Location = new System.Drawing.Point(517, -106);
            this.pipe_up2.Name = "pipe_up2";
            this.pipe_up2.Size = new System.Drawing.Size(97, 300);
            this.pipe_up2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pipe_up2.TabIndex = 33;
            this.pipe_up2.TabStop = false;
            // 
            // pipe_down2
            // 
            this.pipe_down2.BackColor = System.Drawing.Color.Transparent;
            this.pipe_down2.Image = global::Games.Properties.Resources.piped;
            this.pipe_down2.Location = new System.Drawing.Point(517, 356);
            this.pipe_down2.Name = "pipe_down2";
            this.pipe_down2.Size = new System.Drawing.Size(97, 300);
            this.pipe_down2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pipe_down2.TabIndex = 34;
            this.pipe_down2.TabStop = false;
            // 
            // pipe_up3
            // 
            this.pipe_up3.BackColor = System.Drawing.Color.Transparent;
            this.pipe_up3.Image = global::Games.Properties.Resources.pipeu;
            this.pipe_up3.Location = new System.Drawing.Point(773, -189);
            this.pipe_up3.Name = "pipe_up3";
            this.pipe_up3.Size = new System.Drawing.Size(97, 300);
            this.pipe_up3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pipe_up3.TabIndex = 35;
            this.pipe_up3.TabStop = false;
            // 
            // pipe_down3
            // 
            this.pipe_down3.BackColor = System.Drawing.Color.Transparent;
            this.pipe_down3.Image = global::Games.Properties.Resources.piped;
            this.pipe_down3.Location = new System.Drawing.Point(773, 285);
            this.pipe_down3.Name = "pipe_down3";
            this.pipe_down3.Size = new System.Drawing.Size(97, 300);
            this.pipe_down3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pipe_down3.TabIndex = 36;
            this.pipe_down3.TabStop = false;
            // 
            // fb
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkTurquoise;
            this.ClientSize = new System.Drawing.Size(800, 480);
            this.Controls.Add(this.q_r);
            this.Controls.Add(this.scoreText);
            this.Controls.Add(this.grass);
            this.Controls.Add(this.game_over);
            this.Controls.Add(this.press_enter);
            this.Controls.Add(this.pipe_down1);
            this.Controls.Add(this.pipe_up1);
            this.Controls.Add(this.bird);
            this.Controls.Add(this.pipe_down2);
            this.Controls.Add(this.pipe_up2);
            this.Controls.Add(this.pipe_down3);
            this.Controls.Add(this.pipe_up3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "fb";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fb_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fb_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.fb_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.bird)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_up1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_down1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_up2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_down2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_up3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_down3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label scoreText;
        private System.Windows.Forms.Label press_enter;
        private System.Windows.Forms.Label game_over;
        private System.Windows.Forms.PictureBox bird;
        private System.Windows.Forms.PictureBox pipe_up1;
        private System.Windows.Forms.PictureBox pipe_down1;
        private System.Windows.Forms.PictureBox grass;
        private System.Windows.Forms.Label q_r;
        private System.Windows.Forms.PictureBox pipe_up2;
        private System.Windows.Forms.PictureBox pipe_down2;
        private System.Windows.Forms.PictureBox pipe_up3;
        private System.Windows.Forms.PictureBox pipe_down3;
    }
}